# Reflection Brief — Harness Engineering Capstone

**Name:** Vinod Biradar
**Date:** 2026-09-25

Replace each `→` with your answer. **Every answer cites at least one artifact from your own runs** — a run ID, file path, token count, claim outcome, or test count. Uncited answers do not pass. 3–6 sentences each unless noted. Paste short artifact snippets where they help.

**Environment**

- Model(s):
- OS / Python:
- Approx. API spend:

---

## Part 1 — Per-system

### System 1 — Agentic loop

1. **Loop control.** Quote the `stop_reason` sequence from one trace. Name the file and function that decides continue-vs-stop, and how.
   → The captured trace is `evidence/system1_agentic_loop/property_damage.jsonl`, for `claim_03_water_damage`. The run summary records 6 turns and 2 clarifications for this claim; the exact intermediate stop_reason sequence is not present in the copied evidence.

2. **Anti-pattern.** Name one anti-pattern `test_antipatterns.py` checks for. What would break in your run if the loop used it?
   → The exact anti-pattern name is not present in the captured evidence, so I am not inventing it. The System 1 test evidence is recorded in `evidence/system1_agentic_loop/pytest_S1.log`.

3. **Tool design.** Pick two tools with overlapping inputs. How do the descriptions prevent misrouting? What did a structured tool error let the agent do that a generic string would not?
   → The captured evidence does not contain the tool definitions or structured-error implementation, so the exact two tools cannot be quoted safely. The property-damage trace is recorded in `evidence/system1_agentic_loop/property_damage.jsonl`.

4. **Your numbers.** Quote the turn count and cost for one claim. How does it differ from the README sample, and why?
   → For `claim_03_water_damage`, the run used 6 turns and cost an estimated $0.0293 USD, with 23,012 input tokens and 1,252 output tokens. Artifact: `evidence/system1_agentic_loop/summary.md`, run `20260925_123552`.

### System 2 — Context strategy

5. **The reduction.** From `budget.json`: baseline tokens, assembled tokens, reduction %. Which section dominates the assembled context, and why keep it verbatim?
   → Baseline context was 38,708 tokens; assembled context was 16,796 tokens; reduction was 56.61%. The `active` section dominated at 15,789 tokens. Artifact: `evidence/system2_context_strategy/budget.json`.

6. **Summarize vs preserve.** State the rule for what gets summarized vs kept byte-exact, citing your per-section token numbers.
   → Resolved historical material was compressed while active context remained the dominant section. The refund compression used 12,334 input / 326 output tokens and subscription compression used 11,475 input / 469 output tokens. Artifact: `evidence/system2_context_strategy/budget.json`.

7. **Facts block.** Compare `eval.jsonl` to `eval_control.jsonl`. Which question regressed, and what does that prove?
   → Q6 regressed in the control evaluation. The normal evaluation returned the exact status token `in_progress` and passed, while the control answer failed. Artifacts: `eval.jsonl` and `eval_control.jsonl`.

### System 3 — Claude Code config

8. **Path-scoped rules.** Quote the glob frontmatter from one rule file. Why is it better than a directory-level CLAUDE.md for cross-cutting conventions?
   → The React rule uses `paths: - "src/components/**/*"` and `- "src/pages/**/*"`. Artifact: `evidence/system3_claude_config/evidence_rule_react.md`. This activates the rule only for matching paths instead of applying it broadly through a directory-level CLAUDE.md.

9. **Forked skill.** Quote the `context: fork` and `allowed-tools` lines. What does running forked + read-only buy you? What breaks without it?
   → The skill specifies `context: fork` and read-only tools including Read, Grep, Glob, and read-only Git/GitHub commands. Artifact: `evidence/system3_claude_config/evidence_rule_skill.md`. Forking keeps verbose discovery output out of the main session, while the allowlist prevents modification or deployment.

10. **Scope.** From the validator output: project-level vs user-level scope. Give one example of each from this config.
   → The validator output is `OK`. The project-level example is `./CLAUDE.md`; user-level examples are `~/.claude/CLAUDE.md`, `~/.claude/commands/`, and `~/.claude/skills/`. Artifact: `evidence/system3_claude_config/evidence_rule_claude.md`.

### System 4 — Orchestration

11. **Push work down.** Defects the SQL query returned vs warm-tier total. Name the indexed query. Why does the model never see the full history?
   → The Shift C output reports 0 new defects while the recorded shift summary contains 3 high + 2 medium defects and 1 low repeat defect. Artifact: `evidence/system4_orchestration/shift_run_output.txt`. The exact indexed SQL query is not present in the captured evidence.

12. **Crash recovery.** The resume-vs-fresh decision and its staleness threshold (`recovery.py`). Why is a fresh start with an injected summary sometimes more reliable than resuming?
   → The exact recovery threshold is not present in the captured evidence. The intended reliability principle is to avoid blindly resuming stale state and instead use a fresh start with a trusted summary when persisted state may be stale or incomplete.

13. **Small state.** Byte size of your `hot_state.json`. Why does the budget matter for a system run once per shift, indefinitely?
   → `data/hot_state.json` is 643 bytes. Artifact: `evidence/system4_orchestration/hot_state_size.txt`. Keeping persistent state small prevents unbounded growth across repeated shift executions.

---

## Part 2 — Synthesis

*Graded on connecting two or more systems. Cite a named file/artifact from each.*

14. **Three layers.** Point to a file/artifact for each layer and justify.
    → Model:
    → Harness:
    → Orchestration:

15. **Deterministic vs prompt.** Cite one behavior guaranteed in code (terminal tool, read-only allowlist, atomic write, byte budget) and one guided by prompt. When is each right?
   → The System 3 skill deterministically enforces a read-only `allowed-tools` list. Artifact: `evidence/system3_claude_config/evidence_rule_skill.md`. Prompt-guided behavior is appropriate for flexible reasoning, while deterministic enforcement is better for security-sensitive boundaries.

16. **Context, two faces.** Compare context management in System 2 (intra-session) and System 4 (cross-session) with cited numbers from both. Same principle, different mechanism — how?
   → System 2 reduced context from 38,708 to 16,796 tokens, a 56.61% reduction. System 4 kept hot state to 643 bytes. Artifacts: `budget.json` and `hot_state_size.txt`. Both minimize active state, but System 2 manages intra-session context while System 4 manages persistent cross-session state.

17. **Reliability you can't see in one run.** Name one behavior a test guarantees that a single successful run would not reveal. Why does it matter before shipping?
   → System 2's evaluation distinguishes the normal strategy from the control: Q6 passed with `in_progress` in `eval.jsonl` but failed in `eval_control.jsonl`. This demonstrates reliability that a single successful run would not establish.

18. **Blast radius.** Pick one system. What's the blast radius if it misbehaves, and what's the kill switch? Ground it in that system's tools, enforcement points, and state.
   → System 3 limits blast radius through `context: fork` and the read-only `allowed-tools` list. Artifact: `evidence/system3_claude_config/evidence_rule_skill.md`. The skill is on-demand and cannot independently push or deploy changes.

---

## Part 3 — Honest assessment

19. **What broke.** One thing that failed first try in your environment, and how you fixed it. (If nothing, what you checked to be sure.)
   → System 2 initially failed because no inference backend was available. I configured the required API credentials and `ANTHROPIC_BASE_URL`; the run then completed successfully with run `20260925-150959`.

20. **What you'd change.** One architectural decision you'd make differently, grounded in what you observed.
   → I would automate evidence collection after each run. The project required multiple artifacts across four systems, so automatic evidence collection would reduce the chance of missing a required file while preserving reproducibility.
