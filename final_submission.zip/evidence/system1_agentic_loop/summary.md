# Run summary — 20260925_123552

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1324** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | incomplete | - | - | 2 | 0 | 6371 | 484 | 0.0088 | 5.2 |
| claim_02_stolen_bike | routed | theft | low | 5 | 0 | 16888 | 755 | 0.0207 | 9.4 |
| claim_03_water_damage | routed | property_damage | high | 6 | 2 | 23012 | 1252 | 0.0293 | 15.0 |
| claim_04_neighbor_injury | incomplete | - | - | 3 | 0 | 9253 | 482 | 0.0117 | 7.3 |
| claim_05_auto_collision | routed | auto | high | 4 | 0 | 15706 | 1145 | 0.0214 | 11.8 |
| claim_06_low_confidence_escalation | incomplete | - | - | 3 | 0 | 9447 | 605 | 0.0125 | 8.1 |
| claim_07_tree_falls_on_car | incomplete | - | - | 2 | 0 | 6399 | 511 | 0.009 | 5.8 |
| claim_08_minor_porch_damage | routed | property_damage | low | 4 | 0 | 14549 | 925 | 0.0192 | 10.7 |
